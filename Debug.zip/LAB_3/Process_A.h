#pragma once

void Send_to_B(WCHAR* text);