// LAB_3B.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "LAB_3.h"
#include "Process_A.h"

INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam); //  any executable code that is passed as an argument to other code that is expected to call back (execute) the argument at a given time

int APIENTRY wWinMain(_In_ HINSTANCE hInstance, // for identification exe when is loaded in memory
	_In_opt_ HINSTANCE hPrevInstance, // for 16-bit wondows
	_In_ LPWSTR    lpCmdLine, // comand-line arguments as UNICODE string
	_In_ int       nCmdShow) //  is a flag that says whether the main application window will be minimized, maximized, or shown normally.
{
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_ABOUTBOX), NULL, About);
	return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam); // ������, ������� �� ���� �� ����������
	switch (message)
	{
	case WM_INITDIALOG: 
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		if (LOWORD(wParam) == IDC_BUTTON_A)
		{
			WCHAR buf[1001];
			GetDlgItemText(hDlg, IDC_EDIT_A, buf, 1000);

			Send_to_B(buf);
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
